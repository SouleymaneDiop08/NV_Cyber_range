# Install this package as a python alternative.
# PYTHON_VERSION=2.7
# PYTHON_PRIORITY=27
/usr/sbin/alternatives --install /usr/bin/python python /usr/bin/python2.7 27
rm -f /usr/share/icons/hicolor/icon-theme.cache
