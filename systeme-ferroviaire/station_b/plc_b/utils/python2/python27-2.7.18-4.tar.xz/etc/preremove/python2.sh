# Remove this package as a python alternative.
/usr/sbin/alternatives --remove python /usr/bin/python2.7 
